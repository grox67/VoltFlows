package com.voltflow.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(5, 8, 20))
        }
        val title = TextView(this).apply {
            text = "⚡ VOLTFLOW"
            textSize = 32f
            setTextColor(Color.rgb(85, 245, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your phone. Your charging style.\n\nConnect your charger to try the lock-screen animation.\n\nKeep in mind: Android versions and phone brands may restrict automatically opening an activity over the lock screen."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val preview = Button(this).apply {
            text = "Preview animation"
            setOnClickListener { startActivity(Intent(this@MainActivity, ChargingActivity::class.java)) }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(preview)
        setContentView(root)
    }
}
