package com.voltflow.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.IntentFilter
import android.content.BroadcastReceiver
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.view.Gravity
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator
import android.os.BatteryManager
import kotlin.math.*

class ChargingActivity : Activity() {
    private var unplugReceiver: BroadcastReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.statusBarColor = Color.rgb(3, 5, 10)
        window.navigationBarColor = Color.rgb(3, 5, 10)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(3, 5, 10)) }
        root.addView(TimelineThroneView(this) { batteryPercent() },
            FrameLayout.LayoutParams(-1, -1))

        val hint = TextView(this).apply {
            text = "CHARGING  •  VOLTFLOW: LOKI EDITION\\nTap anywhere to close"
            textSize = 11f
            letterSpacing = 0.13f
            setTextColor(Color.rgb(176, 153, 92))
            gravity = Gravity.CENTER
        }
        val hintParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        hintParams.bottomMargin = 48
        root.addView(hint, hintParams)
        root.setOnClickListener { finish() }
        setContentView(root)

        unplugReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_POWER_DISCONNECTED) finish()
            }
        }
        registerReceiver(unplugReceiver, IntentFilter(Intent.ACTION_POWER_DISCONNECTED))
    }

    private fun batteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val value = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return if (value in 0..100) value else 0
    }

    override fun onDestroy() {
        unplugReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        super.onDestroy()
    }

    private class TimelineThroneView(
        context: Context,
        private val getPercent: () -> Int
    ) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        private val emerald = Color.rgb(35, 235, 142)
        private val gold = Color.rgb(226, 187, 91)
        private val mutedGold = Color.rgb(112, 83, 38)
        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 5200
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
        }

        init { animator.start() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = w / 2f
            val cy = h * 0.46f
            val scale = min(w, h) / 420f
            canvas.save()
            canvas.scale(scale, scale, cx, cy)
            val cX = cx / scale
            val cY = cy / scale
            drawStars(canvas, w / scale, h / scale)
            drawTimelines(canvas, cX, cY)
            drawPortal(canvas, cX, cY)
            drawThrone(canvas, cX, cY)
            canvas.restore()
        }

        private fun drawStars(canvas: Canvas, w: Float, h: Float) {
            paint.style = Paint.Style.FILL
            for (i in 0..75) {
                val x = ((i * 73) % 997) / 997f * w
                val y = ((i * 139) % 991) / 991f * h
                paint.color = Color.argb(65 + (i % 4) * 25, 185, 210, 190)
                canvas.drawCircle(x, y, if (i % 7 == 0) 2.0f else 0.8f, paint)
            }
        }

        private fun drawTimelines(canvas: Canvas, cx: Float, cy: Float) {
            // Many glowing timeline strands flow inward from the edges into the central time circle.
            for (i in 0 until 13) {
                val yStart = cy - 205f + i * 34f
                val fromLeft = Path().apply {
                    moveTo(-45f, yStart)
                    cubicTo(cx * 0.32f, yStart - 45f + sin(phase * 6.28f + i) * 18f,
                        cx * 0.60f, cy + (i - 6) * 20f, cx - 128f, cy + (i - 6) * 8f)
                }
                val fromRight = Path().apply {
                    moveTo(cx * 2f + 45f, yStart)
                    cubicTo(cx * 1.68f, yStart + 45f + cos(phase * 6.28f + i) * 18f,
                        cx * 1.40f, cy + (i - 6) * 20f, cx + 128f, cy + (i - 6) * 8f)
                }
                val alpha = 80 + ((sin(phase * 6.28f + i * 0.7f) + 1f) * 55).toInt()
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = if (i % 3 == 0) 3.2f else 1.5f
                paint.strokeCap = Paint.Cap.ROUND
                paint.color = Color.argb(alpha, 32, 224, 137)
                paint.maskFilter = BlurMaskFilter(9f, BlurMaskFilter.Blur.NORMAL)
                canvas.drawPath(fromLeft, paint)
                canvas.drawPath(fromRight, paint)
                paint.maskFilter = null
                paint.color = Color.argb(alpha, 76, 255, 174)
                canvas.drawPath(fromLeft, paint)
                canvas.drawPath(fromRight, paint)
            }
            // Moving sparks travel along the converging streams.
            paint.style = Paint.Style.FILL
            for (i in 0..17) {
                val t = (phase + i / 18f) % 1f
                val x = if (i % 2 == 0) -20f + (cx - 108f + 20f) * t else cx * 2f + 20f - (cx - 108f + 20f) * t
                val y = cy + sin(t * Math.PI * 2 + i) * (1f - t) * 115f
                paint.color = Color.argb(180, 87, 255, 177)
                paint.setShadowLayer(13f, 0f, 0f, emerald)
                canvas.drawCircle(x, y, 2.5f + (i % 3), paint)
                paint.clearShadowLayer()
            }
        }

        private fun drawPortal(canvas: Canvas, cx: Float, cy: Float) {
            val r = 124f
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(105, 5, 25, 20)
            canvas.drawCircle(cx, cy, r + 15f, paint)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3.5f
            paint.color = Color.argb(100, 46, 255, 157)
            paint.setShadowLayer(24f, 0f, 0f, emerald)
            canvas.drawCircle(cx, cy, r + 9f + sin(phase * 6.28f) * 3f, paint)
            paint.clearShadowLayer()
            paint.strokeWidth = 2f
            paint.color = gold
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.argb(170, 38, 235, 139)
            canvas.drawArc(cx-r-6, cy-r-6, cx+r+6, cy+r+6,
                phase * 360f, 115f, false, paint)
            canvas.drawArc(cx-r-6, cy-r-6, cx+r+6, cy+r+6,
                phase * 360f + 180f, 70f, false, paint)

            // Small gold markers around the time circle.
            for (i in 0 until 48) {
                val a = Math.PI * 2 * i / 48
                val inner = r + 13f
                val outer = inner + if (i % 4 == 0) 10f else 4f
                paint.strokeWidth = if (i % 4 == 0) 2.2f else 1f
                paint.color = if (i % 4 == 0) gold else mutedGold
                canvas.drawLine(
                    cx + cos(a).toFloat() * inner, cy + sin(a).toFloat() * inner,
                    cx + cos(a).toFloat() * outer, cy + sin(a).toFloat() * outer, paint
                )
            }
        }

        private fun drawThrone(canvas: Canvas, cx: Float, cy: Float) {
            // Stylized original fantasy throne silhouette, with Loki-inspired emerald and gold details.
            val top = cy - 91f
            val seatY = cy + 68f
            val path = Path().apply {
                moveTo(cx - 66f, seatY + 26f)
                lineTo(cx - 58f, top + 43f)
                lineTo(cx - 83f, top - 4f)
                lineTo(cx - 44f, top + 12f)
                lineTo(cx - 25f, top - 40f)
                lineTo(cx, top + 4f)
                lineTo(cx + 25f, top - 40f)
                lineTo(cx + 44f, top + 12f)
                lineTo(cx + 83f, top - 4f)
                lineTo(cx + 58f, top + 43f)
                lineTo(cx + 66f, seatY + 26f)
                lineTo(cx + 48f, seatY + 42f)
                lineTo(cx - 48f, seatY + 42f)
                close()
            }
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(20, 36, 30)
            paint.setShadowLayer(18f, 0f, 0f, emerald)
            canvas.drawPath(path, paint)
            paint.clearShadowLayer()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            paint.color = gold
            canvas.drawPath(path, paint)

            // Seat and armrests.
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(91, 64, 28)
            canvas.drawRoundRect(cx - 76f, seatY + 16f, cx + 76f, seatY + 43f, 8f, 8f, paint)
            paint.color = Color.rgb(30, 115, 76)
            canvas.drawRoundRect(cx - 58f, seatY - 1f, cx + 58f, seatY + 24f, 9f, 9f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = gold
            canvas.drawRoundRect(cx - 58f, seatY - 1f, cx + 58f, seatY + 24f, 9f, 9f, paint)

            // Percentage sits on the throne seat, as the centrepiece.
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            paint.textSize = 43f
            paint.color = Color.WHITE
            paint.setShadowLayer(16f, 0f, 0f, emerald)
            canvas.drawText("${getPercent()}%", cx, seatY + 10f, paint)
            paint.clearShadowLayer()

            paint.textSize = 10f
            paint.letterSpacingCompat()
            paint.color = gold
            canvas.drawText("THE SACRED TIMELINE", cx, seatY + 62f, paint)
        }

        private fun Paint.letterSpacingCompat() {
            // Canvas text remains compatible with older Android versions.
            textScaleX = 1.08f
        }
    }
}
