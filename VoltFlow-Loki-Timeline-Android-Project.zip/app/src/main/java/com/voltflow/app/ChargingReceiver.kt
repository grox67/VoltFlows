package com.voltflow.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ChargingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> {
                val screen = Intent(context, ChargingActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                try {
                    context.startActivity(screen)
                } catch (_: Exception) {
                    // Newer Android releases may block background activity launches.
                    // The user can still open VoltFlow and use Preview.
                }
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                // The charging screen closes itself when it detects unplugging.
            }
        }
    }
}
